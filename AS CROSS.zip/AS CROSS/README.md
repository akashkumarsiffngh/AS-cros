
# Game Project

This is a simple HTML-based game. Follow the steps below to host it on GitHub:

## Steps to Host
1. Upload the files to a GitHub repository.
2. Go to the repository's Settings > Pages.
3. Select the `main` branch and set the directory to `/root`.
4. Your game will be live at `https://<your-github-username>.github.io/<repository-name>`.

## File Description
- **index.html**: Main file for the game.

Enjoy!
